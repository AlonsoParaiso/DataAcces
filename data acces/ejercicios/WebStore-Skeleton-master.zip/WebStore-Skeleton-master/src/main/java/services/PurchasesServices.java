/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;

import model.Purchase;

/**
 *
 * @author dam2
 */
public class PurchasesServices {

    public ArrayList<Purchase> getAllPurchases() {
        ArrayList<Purchase> purch =  null;
        return purch;
    }

    public ArrayList<Purchase> searchByDate(String date) {
        ArrayList<Purchase> purch =  null;
        return purch;
    }

    public ArrayList<Purchase> getPurchasesByClientId(int id) {
        ArrayList<Purchase> purch =  null;
        return purch;
    }

    public void deletePurchase(Purchase purchase) {
     }

    public Purchase addPurchase(String customerId, String itemId, String date) {
        Purchase newPurchase = null;
        return newPurchase;
    }

}
