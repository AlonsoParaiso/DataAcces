package dao;

public interface DaoTest extends Dao<Test>{

    public int dameNumero();
    public String dameNombre();
}
