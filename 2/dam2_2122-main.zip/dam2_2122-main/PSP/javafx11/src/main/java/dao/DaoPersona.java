package dao;

import modelo.Persona;

public interface DaoPersona {
    boolean addPersona(Persona p);
}
