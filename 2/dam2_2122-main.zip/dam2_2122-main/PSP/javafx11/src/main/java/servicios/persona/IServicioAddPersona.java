package servicios.persona;

import modelo.Persona;

public interface IServicioAddPersona {
    boolean addPersona(Persona p);
}
