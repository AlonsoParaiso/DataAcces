package dao;

public class Test {

    private String hola;
}
