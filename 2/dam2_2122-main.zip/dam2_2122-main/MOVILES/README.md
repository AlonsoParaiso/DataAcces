# dam2_2122

- Kotlin
   - definicion de variables
        - var, val
        - tipos
   - variables estaticas
  
- Primera App
  - Control activity
  - layout 
      - frame, linear horizontal vertical weigth ,constraitnlayout chainstyle, vo h bias, 
  - resources
    
