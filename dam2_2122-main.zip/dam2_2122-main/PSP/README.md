# dam2_2122

PSP

- HTTP
   - llamadas cliente Retrofit
   - control de errores
   - llamadas asincronas Task, rxJava, retrofit
   - Servidor Parametros, Session
   - JAX-RS, controllers, control de errores.

- Seguridad
    - Login y hash contraseñas, registro por mail.
    - Encriptacion simetrica y asimetrica
    - Certificados.
    
- WebSokets    
