package dao.modelo.marvel;

public class MarvelComics extends Marvel{




}
