/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.ArrayList;
import model.Customer;

/**
 *
 * @author Laura
 */
public class CustomersServices {

    public ArrayList<Customer> getAllCustomers() {
        ArrayList<Customer> custo =  null;
        return custo;
    }

        public ArrayList<String> searchById(int id) {
            ArrayList<String> st =  null;
            return st;
    }

    public void deleteCustomer(Customer customer) {

    }

    public Customer addCustomer(String customerId, String name, String phone, String address) {
        Customer custo =  null;
        return custo;
    }

}
