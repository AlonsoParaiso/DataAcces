package dao.modelo;

import lombok.Data;

@Data
public class Filters {
}
