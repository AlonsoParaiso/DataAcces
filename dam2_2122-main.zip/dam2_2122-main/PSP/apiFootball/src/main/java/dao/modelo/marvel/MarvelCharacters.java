package dao.modelo.marvel;

import lombok.Data;

@Data
public class MarvelCharacters extends Marvel{

    //    @Expose
    private DataCharacters data;
}
